const express = require('express');
const session = require('express-session');
const crypto = require('crypto');
const app = express();
const path = require('path');
const { Client } = require('pg');


const bodyParser = require('body-parser');

// Generate a random secret key
const secretKey = crypto.randomBytes(128).toString('hex');

//middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
    secret: secretKey,
    resave: false,
    saveUninitialized: false
}));


// Defined routes
app.get('/login', async (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', async (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
            res.status(500).send('Error logging out');
        } else {
            res.redirect('/login'); 
        }
    });
});

app.get('/forgotpassword', async (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'forgotpassword.html'));
});

app.get('/changepassword', async (req, res) => {
    if (!req.session.username) {
        return res.sendFile(path.join(__dirname, 'public', 'error.html')); // Show error page
    }
    res.setHeader('Cache-Control', 'no-store'); 
    res.sendFile(path.join(__dirname, 'public', 'changepassword.html'));
});

app.get('/main', async (req, res) => {
    if (!req.session.username) {
        return res.sendFile(path.join(__dirname, 'public', 'error.html')); // Show error page
    }
    res.setHeader('Cache-Control', 'no-store'); 
    res.sendFile(path.join(__dirname, 'public', 'main.html'));
});


// Start the server
const port = 3002; // or any port of your choice
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// Database connection
const db = new Client({
    user: "postgres",
    host: "localhost",
    database: "postgres",
    password: "123456",
    port: 5432,
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to database', err.stack);
    } else {
        console.log('Connected to database');
    }
});


//SQL injection , write it inside password and repeat password
//'); DROP TABLE users; --
app.post('/register', async (req, res) => {
    const { username, firstname, lastname, email, password, repeatPassword } = req.body;
    
    try {
        if (!username || !firstname || !lastname || !email || !password || !repeatPassword) {
            return res.status(400).send('All fields are required');
        }

        if (password !== repeatPassword) {
            return res.status(400).send('Passwords mismatch');
        }

        const query = `INSERT INTO users (username, firstname, lastname, email, password) 
        VALUES ('${username}', '${firstname}', '${lastname}', '${email}', '${password}')`;

        const result = await db.query(query);

        res.status(200).send('User registered successfully');
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).send('Error registering user');
    }
});

//SQL injection
//' OR '1'='1
app.post('/login', async (req, res) => {

    const { username, password } = req.body;

    try {
        // Query the database to check if the user exists
        const result = await db.query("SELECT * FROM users WHERE username = '"+ username + "' AND password = '" + password+ "' LIMIT 1");
        
        // If user exists, send a success response
        if (result.rows.length > 0) {
            req.session.username = username; // Set session variable upon successful login
            res.redirect('/main');
        } else {
            // If user doesn't exist, send an error response
            res.status(401).send('Invalid username or password');
        }
    } catch (error) {
        // Send an error response if there's an error with the database query
        console.error('Error logging in:', error);
        res.status(500).send('Error logging in');
    }

});

// Add new client
app.post('/addClient', async (req, res) => {
    const { clientFirstName, clientLastName, clientId, clientEmail, clientPhone } = req.body;

    try {
        // Check if user is authenticated
        if (!req.session.username) {
            return res.status(401).send('Unauthorized');
        }

        // Insecure query construction
        const query = `INSERT INTO clients (first_name, last_name, client_id, email, phone) 
        VALUES ('${clientFirstName}', '${clientLastName}', '${clientId}', '${clientEmail}', '${clientPhone}') RETURNING *`;

        // Execute the query
        const result = await db.query(query);

        // Send the inserted row as JSON response
        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error('Error adding client:', error);
        res.status(500).send('Error adding client');
    }
});

app.post('/changePassword', async (req, res) => {
    if (!req.session.username) {
        return res.status(401).send('Unauthorized');
    }
    const { currentPassword, newPassword } = req.body;
    const username = req.session.username;
    try {
        // Query the database to get the password for the current user
        const result = await db.query("SELECT password FROM users WHERE username = $1", [username]);
        if (result.rows.length === 0) {
            return res.status(400).send('User not found');
        }
        
        const dbPassword = result.rows[0].password;

        // Compare the password with the current password provided by the user
        if (currentPassword !== dbPassword) {
            return res.status(400).send('Current password is incorrect');
        }

        // Compare the current password in the db with the new password provided by the user
        if (dbPassword == newPassword) {
            return res.status(400).send('New password cannot be the same as current password');
        }

        // Update the password in the database
        await db.query("UPDATE users SET password = $1 WHERE username = $2", [newPassword, username]);

        // Send a success response
        res.status(200).send('Password changed successfully');
    } catch (error) {
        console.error('Error changing password:', error);
        res.status(500).send('Error changing password');
    }
});
