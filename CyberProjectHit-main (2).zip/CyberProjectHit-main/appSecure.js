const express = require('express');
const session = require('express-session');
const app = express();
const path = require('path');
const { Client } = require('pg');

const bodyParser = require('body-parser');


//middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


// Define route for 'home'
app.get('/login', async (req, res) => {
    // Send the HTML file located in the 'public' directory
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', async (req, res) => {
    // Send the HTML file located in the 'public' directory
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/forgotpassword', async (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'forgotpassword.html'));
});

app.get('/changepassword', async (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'changepassword.html'));
});

app.get('/main', async (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'main.html'));
});


// Start the server
const port = 3002; // or any port of your choice
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// Database connection
const db = new Client({
    user: "postgres",
    host: "localhost",
    database: "postgres",
    password: "123456",
    port: 5432,
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to database', err.stack);
    } else {
        console.log('Connected to database');
    }
});


app.post('/register', async (req, res) => {
    const { username, firstname, lastname, email, password, repeatPassword } = req.body;
    
    try {
        if (!username || !firstname || !lastname || !email || !password || !repeatPassword) {
            return res.status(400).send('All fields are required');
        }

        if (password !== repeatPassword) {
            return res.status(400).send('Passwords mismatch');
        }

        const query = `INSERT INTO users (username, firstname, lastname, email, password) VALUES ($1, $2, $3, $4, $5)`;
        const values = [username, firstname, lastname, email, password]; 
        const result = await db.query(query, values);
        
        res.status(200).send('User registered successfully');
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).send('Error registering user');
    }
});


app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // Use parameterized query to prevent SQL injection
        const query = "SELECT * FROM users WHERE username = $1 AND password = $2 LIMIT 1";
        const values = [username, password];
        const result = await db.query(query, values);

        // If user exists, send a success response
        if (result.rows.length > 0) {
            res.redirect('/main');
            res.status(200).send('Login successful');
        } else {
            // If user doesn't exist, send an error response
            res.status(401).send('Invalid username or password');
        }
    } catch (error) {
        // Send an error response if there's an error with the database query
        console.error('Error logging in:', error);
        res.status(500).send('Error logging in');
    }
});


// Add new client
app.post('/addClient', async (req, res) => {
    const { clientFirstName, clientLastName, clientId, clientEmail, clientPhone } = req.body;

    try {
        const query = `INSERT INTO clients (first_name, last_name, client_id, email, phone) 
        VALUES ($1, $2, $3, $4, $5)`;
        const values = [clientFirstName, clientLastName, clientId, clientEmail, clientPhone];

        await db.query(query, values);

        res.status(200).send('Successfull add client');

    } catch (error) {
        console.error('Error adding client:', error);
        res.status(500).send('Error adding client');
    }
});


